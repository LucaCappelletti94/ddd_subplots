"""Current version of package ddd_subplots"""
__version__ = "1.0.20"
